package com.example.pointofsale;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends Activity {

    EditText edt1,edt2;
    Button b1,b2;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        edt1 = findViewById(R.id.username);
        edt2 = findViewById(R.id.password_toggle);
        b1 = findViewById(R.id.btn1);
        b2 = findViewById(R.id.btn2);

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Login();
            }
        });
    }
    public void Login(){
        String username = edt1.getText().toString();
        String password = edt2.getText().toString();

        if(username.equals("")||password.equals("")){
            Toast.makeText(this,"工号、密码为空白",Toast.LENGTH_LONG).show();
        }
        else if(username.equals("1001") && password.equals("1001")){
            Toast.makeText(this,"登陆成功",Toast.LENGTH_LONG).show();
            Intent intent = new Intent(LoginActivity.this,FullscreenActivity.class);
            startActivity(intent);
        }
        else{
            Toast.makeText(this,"工号、密码不匹配",Toast.LENGTH_LONG).show();
        }
    }
}
