package com.example.pointofsale;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;

public class paymentActivity extends AppCompatActivity {
    private static final int OUT = 1;
    private static final int IN = 2;
    private DBManager mgr;
    private EditText etCount,etUserName;
    private RadioGroup radioGroup;
    private TextView tvInfo;
    private Button btnAdd;
    private Button btnFinish;
    private int countType = OUT;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
        //初始化DBManager
        mgr = new DBManager(this);
        etCount = (EditText) findViewById(R.id.dialog_saleInput);
        etUserName = (EditText) findViewById(R.id.username);
        radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        tvInfo = (TextView)findViewById(R.id.tvInfo);
        btnAdd = (Button)findViewById(R.id.confirm);
        btnFinish = (Button)findViewById(R.id.finish);

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.radioOut:
                        countType = OUT;
                        break;
                    case R.id.radioIn:
                        countType = IN;
                        break;
                }
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Count count = new Count();
                long time = System.currentTimeMillis();
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String str = format.format(new Date(time));
                count.setDate(str);
                count.setMoney(Double.parseDouble(etCount.getText().toString()));
                count.setUserName(etUserName.getText().toString());
                count.setType(countType + "");
                mgr.insert(count);      //插入数值
                resetInfo();
            }
        });
        resetInfo();
        btnFinish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(paymentActivity.this,POSActivity.class);
                startActivity(intent);
            }
        });
    }

    public void resetInfo(){
        Double in = mgr.getResult(IN);
        tvInfo.setText("当前金额为："+in);
        Double out = mgr.getResult(OUT);
        tvInfo.setText("当前金额有异常："+out);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //应用的最后一个Activity关闭时应释放DB
        mgr.closeDB();
    }

}
